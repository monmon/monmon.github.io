%commit = (
  "0da5342f6312940a08c31db6b14a3032cd5b4f2a" => {
    body => "",
    extra => "",
    gpgsig => "-----BEGIN PGP SIGNATURE-----\nVersion: GnuPG v1.4.12 (GNU/Linux)\n\niQEcBAABAgAGBQJSwvCMAAoJEOX2RRt2IcQDZacH/0qGZ7YOoQ+FmZ2yBEFhWlBL\nP/k+gk3CSHvg/br1M7kJfNl7wGSoAv1rez3kx/gUPxcBYVjtw3foTF4IO+xd8cpN\ntD7S6Bds4UVqihLarLW80NhVEb0Wit5E5xOsPn1gvVyJRq/lxQEz2/JglY4Y+c4n\n+W1jzaLrGZDR2JZbmGZ3qONXIbRToNeX89YFBdxez1ZkHGsEse+gK9wuVyyOBxvx\nu3Es5Hz9qQDgg6JdVub9/P/QwrodewOkErn80E4CiacXOyWwHUVk1RfRz16dJgYx\n3TIlNIDrnSU8vPnOfL10m8VpVaapIfs17LeRjQCT8FlATcdz/6GNmArvPo0/urA=\n=6U5E\n-----END PGP SIGNATURE-----",
    mergetag => [
      "object 6656508287f92c541906764e0bd9fc4a096d7a52\ntype commit\ntag v1.0.3\ntagger Example Committer <committer\@example.com> 1388507274 +0100\n\nsigned tag\n-----BEGIN PGP SIGNATURE-----\nVersion: GnuPG v1.4.12 (GNU/Linux)\n\niQEcBAABAgAGBQJSwvCMAAoJEOX2RRt2IcQD+rsH/i+CQHJnGunJia/GhQGrsi2C\n5d8yaN6Yx0WNRQ1Wj6Yh/PI3vzLt79JIesmefW/0nOzmFtF+NsLgLjsmxjnwuMO9\n1/u6uc9TBv9xshfJMyVj3KB0GRUyU00QE4vUKuy34KfR2CoQ0swHPSrN+H6UQfNh\ne5CJReb4orefQJKgShjgh0RG/ApdpIiQYMQzD9GFQ9Yk9YG8O+usOLLBvXTaG85R\nKNKapRhRr8cqSeQ6WHSGqLP7B3yj8gOR9/N3bc4JTtOScubXanVRCETc5mSPOgkE\nKpaXRF+Z8lGcBENWWmmv/ctlgnAQPCzuVwfdPBTCY+jUPzawxs2d5y7E/nCjgiE=\n=R6sc\n-----END PGP SIGNATURE-----"
    ],
    parent => [
      "bf9c28859ac7ef3fa9349d3c8c135b0a4d925375",
      "6656508287f92c541906764e0bd9fc4a096d7a52"
    ],
    subject => "buen d\303\255a (es)",
    tree => "7b8f01341e59251bbf067b1001cdd12f44c36847"
  },
  "14d006328eed0b5cab47e4c970cbc9c8ec914492" => {
    body => "",
    extra => "",
    gpgsig => "-----BEGIN PGP SIGNATURE-----\nVersion: GnuPG v1.4.12 (GNU/Linux)\n\niQEcBAABAgAGBQJSwvCNAAoJEOX2RRt2IcQDcDkH/1Tv4aw/2LGZp2s1IaLUwlNY\nQqfJSumnTu0cCcBiGJrs5L2i/z81DmTnTJULKsEPH4pvXaEBsvNEXprV76xrvAJ8\nQJy++Hhy0HB4Gd4jQLEZfQ++NuUwZtF3Wo/jZ6dehf72VQ7P2zGE3vnNMGswSfyc\ny4px3Ok0+f4+KiBJKOWRFk7aVnXnY9MAuv3yplZ7KnzvDGt5J9J9rt+wTXATdtvH\nVkUQEERYEv9+ggy6m9TIKW0y1BA+/VxapO1pjdxy+q65l/NlvxdC2nwgD5loOQRb\nd8aqpM0DvgJhDzIhWrJUYFes1td8w3lpHO0VIGqZ4WA6/5pi5WIftJOKBMNfWIU=\n=SskS\n-----END PGP SIGNATURE-----",
    mergetag => [
      "object b5ed6ffa078b72dbad6ef354a33c3f242ec6806e\ntype commit\ntag v1.1.0\ntagger Example Committer <committer\@example.com> 1388507274 +0100\n\nsigned tag\n-----BEGIN PGP SIGNATURE-----\nVersion: GnuPG v1.4.12 (GNU/Linux)\n\niQEcBAABAgAGBQJSwvCMAAoJEOX2RRt2IcQDFyMH/2raUGdOR3uairb67YWIcA2w\ngU1RQ3u59TFj6Zx1TUEWskiMT9CCsmLt1f34tAcusXscLg9GfLUXDtgqVsR/hH52\nMmlC7ZCnCcP+IADuuY7NR4xdGtfOHATf/ZNK6XgHEj44BmaVEeImA2w4Kcd9vl0V\nGzydkXie4FuAu9h1C4xrZPa/HuoyP4jb97QhxJbNY63dR+LGInyet2OIZmGJibR1\nVFwDbtw7z4th9THvt0Uxn1pehDQYd1nZ3MM+29sp0s3jR7BJcmncr3hdDTvvGT2o\nnmVRXVVDDefbEyR4tzp2ggET0Tv11KLJCNsdIFVpY8KPesuYJi6FyYhtsjtHGMo=\n=v70J\n-----END PGP SIGNATURE-----",
      "object cf7fc372d2396dd4381a758e95ddefd008f771e1\ntype commit\ntag v1.0.2\ntagger Example Committer <committer\@example.com> 1388507274 +0100\n\nsigned tag\n-----BEGIN PGP SIGNATURE-----\nVersion: GnuPG v1.4.12 (GNU/Linux)\n\niQEcBAABAgAGBQJSwvCLAAoJEOX2RRt2IcQDfhQH/27cuWMLuL+dsfwLvbJJyKEK\nR3QJf28rZBtg/InNGbvwbDgt5/zgGBwTSNlHwu23VC58o2hEHnoMpqcuqG/9ve28\nRfQ++Rc0h0uL0RLEm4hKl47foql0rvRvqPB0oTWTbu8JQI6XNmMj7AkxO9qx4DDr\nmF8SwrpkeNl9p8dhvbgjfptGlbYUXj+OhCv6zsQDuciwHs28XkJZpShSF1U019oi\nRUntTMrkd4I8+y/YP0/LgnANUGwuPLqxGXdxdHWMaQnSN4YW/Okvt3nJScwGby5W\nxnDtM/6XbZuwT3+mlW/5WaRMWsqs8pk2u+gX6Vgf2uVL4rf9f8XQHnRkG4jB+1M=\n=ou7+\n-----END PGP SIGNATURE-----"
    ],
    parent => [
      "b77f7c42a5357b0a95bce67df5953e6ed7b2cf2d",
      "b5ed6ffa078b72dbad6ef354a33c3f242ec6806e",
      "cf7fc372d2396dd4381a758e95ddefd008f771e1"
    ],
    subject => "buon giorno (it)",
    tree => "4b825dc642cb6eb9a060e54bf8d69288fbee4904"
  },
  "1fb0b07788e7eaf3fae2f8359c8149399618be06" => {
    body => "",
    extra => "",
    parent => [
      "bea869658b6eff2ab90e603b69f71259a06fd0ae"
    ],
    subject => "hall\303\263 (is)",
    tree => "1840015fc84bf133760c966eed4c1b4047ea657a"
  },
  "472a79ed0821778fd06c7bef3e8488ce87688a06" => {
    body => "",
    extra => "",
    parent => [],
    subject => "hello (en)",
    tree => "fa85af1dc631f3f8d977aafe0253b1d02eb2c4c7"
  },
  "57736d611050201c30b328406b4638212ce26bfd" => {
    body => "",
    extra => "",
    parent => [
      "0da5342f6312940a08c31db6b14a3032cd5b4f2a"
    ],
    subject => "add the README",
    tree => "84a4c2b6522149a6aed2f3945da5cff7b95a358a"
  },
  "6656508287f92c541906764e0bd9fc4a096d7a52" => {
    body => "",
    extra => "",
    parent => [
      "cf7fc372d2396dd4381a758e95ddefd008f771e1"
    ],
    subject => "",
    tree => "524a684865d9b37e0a7236df14ccde01501f063d"
  },
  "7320b9621b2fe6067729bec0676b1229dc4c094f" => {
    body => "",
    extra => "",
    mergetag => [
      "object 8fd90f83295eb00b056f21ae65e7381920aea3bc\ntype commit\ntag v1.0.1\ntagger Example Committer <committer\@example.com> 1388507274 +0100\n\n\303\243\302\201\302\223\303\243\302\202\302\223\303\243\302\201\302\253\303\243\302\201\302\241\303\243\302\201\302\257\n-----BEGIN PGP SIGNATURE-----\nVersion: GnuPG v1.4.12 (GNU/Linux)\n\niQEcBAABAgAGBQJSwvCLAAoJEOX2RRt2IcQDe2kH/1cOG4c6Qr/BjK4dHyvPQ8n4\nBTbMCp3HcIbtAdsDOIfv0QHSBD5sXMboU5aaP3M+NSC3RcxhwIvIw4VaHTRPQIoI\nmXeTYypIbcyQHbcQzrswXw8Ewe3ZZ2rxABmXHFIlRm+mn4p2LWxO99lRNBnQLsET\n50RuGiJx3tyOA4SUOfTpXJ477CoI48t5CS9GyEDMTdXJuEzMohkb5umySA+GtmOL\nTyqx104ET7hMkitcprYRsA/Xl/h5u9oj7/pOCcyCSUnbMPbtE6Iyb1oCJvfwrss2\nLKMY4eMdkVk++Jy6GuEduIkCCjulEHU8baDlP8upJExWlrNVT8G2kUltOLqJLJg=\n=YOwt\n-----END PGP SIGNATURE-----"
    ],
    parent => [
      "b5ed6ffa078b72dbad6ef354a33c3f242ec6806e",
      "8fd90f83295eb00b056f21ae65e7381920aea3bc"
    ],
    subject => "dobr\303\275 den (cs)",
    tree => "7b8f01341e59251bbf067b1001cdd12f44c36847"
  },
  "7b1c51494dafb4c4e981cc09371e1c26129d9fe2" => {
    body => "",
    extra => "",
    gpgsig => "-----BEGIN PGP SIGNATURE-----\nVersion: GnuPG v1.4.12 (GNU/Linux)\n\niQEcBAABAgAGBQJSwvCLAAoJEOX2RRt2IcQDKDAIAI4BdDRcjZnJa+876tLNzpJD\nEhhkujcpWeZOml7kP1I8WC/W+H7eS+/lCX69mkZDz06ISh9JCxs5zVPjMO5GfFzm\nzwql21/VJIa3Eye4MsjrrgIfHXVTUjKSMzRptw+oqWpZNJqOZN/2NCaOBiud5YF+\n/DGPWOZdI+b9CwsljUar/xoKyDVrUjQHcTF/i0jEhMojNBQ/I1RODydaOqQJn0SR\nitj7kZ3UbUrD9MguM8UTALsrMQTu+T6JdQvZ5n0uH4D3qxd8K0sDpZKBeZSmxd66\nxrp1Q/CJEjk7gsUaBH6og2aOkwyYAbRRS/xZQdOVjmwgX/LnpKUPtn/mWDbCuL4=\n=Rqzb\n-----END PGP SIGNATURE-----",
    parent => [
      "cb53cd7ee23bf8498effc165655da63975e9417e"
    ],
    subject => "hej (da)",
    tree => "7b8f01341e59251bbf067b1001cdd12f44c36847"
  },
  "8fd90f83295eb00b056f21ae65e7381920aea3bc" => {
    body => "",
    extra => "",
    parent => [
      "1fb0b07788e7eaf3fae2f8359c8149399618be06"
    ],
    subject => "\343\201\223\343\202\223\343\201\253\343\201\241\343\201\257 (ja)",
    tree => "822aed1f11e71b48d14c899d209b0dca92a08ec8"
  },
  b5ed6ffa078b72dbad6ef354a33c3f242ec6806e => {
    body => "signed tag\n\n# gpg: Signature made Tue Dec 31 17:27:55 2013 CET using RSA key ID 7621C403\n# gpg: Good signature from \"Example Author <author\@example.com>\"\n",
    extra => "",
    mergetag => [
      "object 1fb0b07788e7eaf3fae2f8359c8149399618be06\ntype commit\ntag v1.0.0\ntagger Example Committer <committer\@example.com> 1388507274 +0100\n\nsigned tag\n-----BEGIN PGP SIGNATURE-----\nVersion: GnuPG v1.4.12 (GNU/Linux)\n\niQEcBAABAgAGBQJSwvCLAAoJEOX2RRt2IcQD94AH/3Y+QBWtpPjiIO9BNW0CJTkQ\nTLl0Z69vaW0yhXCmlJ0A1GH/DIFYaxnfduI4vCjsLIQG+3sOuKxZEojs6zj8LeCv\n6ox62fe4SAVJle80/1JK7cJMQawDsoqThyjwf/Gu+WUc2TZF3ZlTI6cslQuXLQbr\nP/tIGDHKDYp9ja4OD9HnlLaVJs64s/PykkWODhar4z3tL7uEVAJFF6PqyPhQUS05\nG24klmfT/lmMDNSfcuWJ+SFzjjAicOCfuww4p9wZon4EfgacQYIwz7Oi522yoFmH\nJWNc7toyaZEENb50ZzggcQsAGdPaamohykKSQj/pJYlmOPVdHR7nDNCeX/poKMM=\n=EPlm\n-----END PGP SIGNATURE-----"
    ],
    parent => [
      "7b1c51494dafb4c4e981cc09371e1c26129d9fe2",
      "1fb0b07788e7eaf3fae2f8359c8149399618be06"
    ],
    subject => "Merge tag 'v1.0.0'",
    tree => "7b8f01341e59251bbf067b1001cdd12f44c36847"
  },
  b77f7c42a5357b0a95bce67df5953e6ed7b2cf2d => {
    body => "",
    extra => "",
    parent => [],
    subject => "empty tree",
    tree => "4b825dc642cb6eb9a060e54bf8d69288fbee4904"
  },
  bea869658b6eff2ab90e603b69f71259a06fd0ae => {
    body => "",
    extra => "",
    parent => [
      "c88c3ff4125c0bfb708a171ac89c4b3e0848bf24"
    ],
    subject => "g\303\263\303\260ur dagur (is)",
    tree => "b090e309a779f2ea76260d10abd027b08fb36362"
  },
  bf9c28859ac7ef3fa9349d3c8c135b0a4d925375 => {
    body => "",
    extra => "",
    gpgsig => "-----BEGIN PGP SIGNATURE-----\nVersion: GnuPG v1.4.12 (GNU/Linux)\n\niQEcBAABAgAGBQJSwvCMAAoJEOX2RRt2IcQDBYAH/ivd449rztZjOZx9ILqlEyqE\nk/Y/aT44nxFJhm9n3ws0H6I4G71sv+o3FZHbIjMmHuxKMtAgXsoa8VpS+7H+B+oE\nKuFIs3XLxbhnsWNHuu9EfdZ6pwL6kr6DSfCjUAgTle8TkAlLYLAWVUeVibIF1ovJ\nH99bC9P4oCfwyiCC++m4nMTISUZIfoB2zu0u6K/u09BHwyaX7S1jUZPB88niyi1Q\nwMift0s3r3D4Yu1EH7W5mO+s36S9yMIKanJn14l3gl6WOIoBb9hAOWuXejWFnK8c\ncrpBIw5igEpWhzxBnESiawNQEWOEIBBTU4YmYNPh9aisIDaL/QcDEKHCtUdEBOE=\n=PcYp\n-----END PGP SIGNATURE-----",
    mergetag => [
      "object cf7fc372d2396dd4381a758e95ddefd008f771e1\ntype commit\ntag v1.0.2\ntagger Example Committer <committer\@example.com> 1388507274 +0100\n\nsigned tag\n-----BEGIN PGP SIGNATURE-----\nVersion: GnuPG v1.4.12 (GNU/Linux)\n\niQEcBAABAgAGBQJSwvCLAAoJEOX2RRt2IcQDfhQH/27cuWMLuL+dsfwLvbJJyKEK\nR3QJf28rZBtg/InNGbvwbDgt5/zgGBwTSNlHwu23VC58o2hEHnoMpqcuqG/9ve28\nRfQ++Rc0h0uL0RLEm4hKl47foql0rvRvqPB0oTWTbu8JQI6XNmMj7AkxO9qx4DDr\nmF8SwrpkeNl9p8dhvbgjfptGlbYUXj+OhCv6zsQDuciwHs28XkJZpShSF1U019oi\nRUntTMrkd4I8+y/YP0/LgnANUGwuPLqxGXdxdHWMaQnSN4YW/Okvt3nJScwGby5W\nxnDtM/6XbZuwT3+mlW/5WaRMWsqs8pk2u+gX6Vgf2uVL4rf9f8XQHnRkG4jB+1M=\n=ou7+\n-----END PGP SIGNATURE-----"
    ],
    parent => [
      "7320b9621b2fe6067729bec0676b1229dc4c094f",
      "cf7fc372d2396dd4381a758e95ddefd008f771e1"
    ],
    subject => "bom dia",
    tree => "7b8f01341e59251bbf067b1001cdd12f44c36847"
  },
  c3beec8670865125228e1e87b30cd940dbc7ac96 => {
    body => "# tag 'v1.1.0'\nsigned tag\n\n# gpg: Signature made Tue Dec 31 17:27:56 2013 CET using RSA key ID 7621C403\n# gpg: Good signature from \"Example Author <author\@example.com>\"\n\n# tag 'v1.0.1'\n\343\201\223\343\202\223\343\201\253\343\201\241\343\201\257\n\n# gpg: Signature made Tue Dec 31 17:27:55 2013 CET using RSA key ID 7621C403\n# gpg: Good signature from \"Example Author <author\@example.com>\"\n",
    extra => "",
    mergetag => [
      "object b5ed6ffa078b72dbad6ef354a33c3f242ec6806e\ntype commit\ntag v1.1.0\ntagger Example Committer <committer\@example.com> 1388507274 +0100\n\nsigned tag\n-----BEGIN PGP SIGNATURE-----\nVersion: GnuPG v1.4.12 (GNU/Linux)\n\niQEcBAABAgAGBQJSwvCMAAoJEOX2RRt2IcQDFyMH/2raUGdOR3uairb67YWIcA2w\ngU1RQ3u59TFj6Zx1TUEWskiMT9CCsmLt1f34tAcusXscLg9GfLUXDtgqVsR/hH52\nMmlC7ZCnCcP+IADuuY7NR4xdGtfOHATf/ZNK6XgHEj44BmaVEeImA2w4Kcd9vl0V\nGzydkXie4FuAu9h1C4xrZPa/HuoyP4jb97QhxJbNY63dR+LGInyet2OIZmGJibR1\nVFwDbtw7z4th9THvt0Uxn1pehDQYd1nZ3MM+29sp0s3jR7BJcmncr3hdDTvvGT2o\nnmVRXVVDDefbEyR4tzp2ggET0Tv11KLJCNsdIFVpY8KPesuYJi6FyYhtsjtHGMo=\n=v70J\n-----END PGP SIGNATURE-----",
      "object 8fd90f83295eb00b056f21ae65e7381920aea3bc\ntype commit\ntag v1.0.1\ntagger Example Committer <committer\@example.com> 1388507274 +0100\n\n\343\201\223\343\202\223\343\201\253\343\201\241\343\201\257\n-----BEGIN PGP SIGNATURE-----\nVersion: GnuPG v1.4.12 (GNU/Linux)\n\niQEcBAABAgAGBQJSwvCLAAoJEOX2RRt2IcQDe2kH/1cOG4c6Qr/BjK4dHyvPQ8n4\nBTbMCp3HcIbtAdsDOIfv0QHSBD5sXMboU5aaP3M+NSC3RcxhwIvIw4VaHTRPQIoI\nmXeTYypIbcyQHbcQzrswXw8Ewe3ZZ2rxABmXHFIlRm+mn4p2LWxO99lRNBnQLsET\n50RuGiJx3tyOA4SUOfTpXJ477CoI48t5CS9GyEDMTdXJuEzMohkb5umySA+GtmOL\nTyqx104ET7hMkitcprYRsA/Xl/h5u9oj7/pOCcyCSUnbMPbtE6Iyb1oCJvfwrss2\nLKMY4eMdkVk++Jy6GuEduIkCCjulEHU8baDlP8upJExWlrNVT8G2kUltOLqJLJg=\n=YOwt\n-----END PGP SIGNATURE-----"
    ],
    parent => [
      "c88c3ff4125c0bfb708a171ac89c4b3e0848bf24",
      "b5ed6ffa078b72dbad6ef354a33c3f242ec6806e",
      "8fd90f83295eb00b056f21ae65e7381920aea3bc"
    ],
    subject => "Merge tags 'v1.1.0' and 'v1.0.1' into mergetags",
    tree => "fa85af1dc631f3f8d977aafe0253b1d02eb2c4c7"
  },
  c88c3ff4125c0bfb708a171ac89c4b3e0848bf24 => {
    body => "",
    extra => "",
    parent => [
      "472a79ed0821778fd06c7bef3e8488ce87688a06",
      "b77f7c42a5357b0a95bce67df5953e6ed7b2cf2d"
    ],
    subject => "Merge branch 'slave'",
    tree => "fa85af1dc631f3f8d977aafe0253b1d02eb2c4c7"
  },
  cb53cd7ee23bf8498effc165655da63975e9417e => {
    body => "",
    extra => "",
    parent => [
      "c88c3ff4125c0bfb708a171ac89c4b3e0848bf24"
    ],
    subject => "\343\201\223\343\202\223\343\201\253\343\201\241\343\201\257 (ja)",
    tree => "51827db31da3d816058b613f19c971e5c4fa6f16"
  },
  cf7fc372d2396dd4381a758e95ddefd008f771e1 => {
    body => "",
    extra => "",
    gpgsig => "-----BEGIN PGP SIGNATURE-----\nVersion: GnuPG v1.4.12 (GNU/Linux)\n\niQEcBAABAgAGBQJSwvCLAAoJEOX2RRt2IcQD11AIAIUtyxP0o1Ob9D6ErF24MVsP\n8bl4nGzd7caGNdi2jCXHJn5k4F5a+Heirc+kYSRapxigJq+rLxVQ0C/JPaz4EnST\no8wjXgW1O3sV6qX0NtFG3GDt870JLTSHNLwpiYNle98gdMcqkJN1ApCYFo6t/wHg\nwDa3Z6CgIJi3CidKi77Dj2QnFYXSeB7Tyrf1IHeKbmFHQkIGb8F34mHqX4YsfO4g\naRsVqymQgimtoR8bOGCQioBGogcGJ0LuHnqoU747rmok7298ZpFqnIWYrxcBuvLL\nrObHMz2FXJystNWn/+JHjQjUhDeqdEXNLbkmioX+z4BOBxcmZoYxHJrkjhBNqzw=\n=vbnw\n-----END PGP SIGNATURE-----",
    parent => [
      "8fd90f83295eb00b056f21ae65e7381920aea3bc"
    ],
    subject => "ol\303\241 (pt)",
    tree => "33a90fc1da2f84bfc394fa886a3d70ae534dc03f"
  }
);
