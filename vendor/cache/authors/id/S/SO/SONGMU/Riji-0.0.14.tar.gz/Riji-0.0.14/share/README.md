1st step -- configuration
--------

Edit your 'riji.yml'.

2nd step -- create your blog entry
--------

Edit your blog entry by markdown notation, save into 'article/entry' and git commit it.
`riji new-entry` sub command is also available helping you to create new entry easily.

3rd step -- confirmation
--------

You can see the blog at local environment by using built in server as following step.

    % riji server

4th step -- publish your entry
--------

You can publish static blog directory as follows.

    % riji publish

'blog/' directory is created. Now, you can publish it to any servers.

5th step -- customize
--------

You can customize your blog design by editing template, css, js or etc in share directory.
