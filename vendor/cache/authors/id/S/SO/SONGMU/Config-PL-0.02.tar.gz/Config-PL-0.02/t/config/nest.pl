use Config::PL;
config_do 'ok.pl';
