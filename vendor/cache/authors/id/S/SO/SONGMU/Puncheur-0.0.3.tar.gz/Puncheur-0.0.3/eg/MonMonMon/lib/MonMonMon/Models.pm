package MonMonMon::Models;
use strict;
use warnings;
use utf8;

use Object::Container -base;

1;
