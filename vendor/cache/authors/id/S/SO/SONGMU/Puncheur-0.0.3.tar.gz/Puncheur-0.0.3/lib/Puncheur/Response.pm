package Puncheur::Response;
use strict;
use warnings;

use parent 'Plack::Response';

1;
