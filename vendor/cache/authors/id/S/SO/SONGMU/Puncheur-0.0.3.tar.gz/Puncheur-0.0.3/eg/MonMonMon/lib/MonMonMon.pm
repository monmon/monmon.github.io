package MonMonMon;
use strict;
use warnings;
use utf8;

use parent 'Puncheur';

__PACKAGE__->load_plugins('Model');

1;
